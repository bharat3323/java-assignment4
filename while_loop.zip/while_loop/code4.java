class Four {
	public static void main(String[] args) {
		char ch = 'A';
		for(int i=1;i<=6;i++){
			if(i%2==0){
				System.out.println(i);
			}else{
				System.out.println(ch);
			}
			ch++;
		}
	}
}
