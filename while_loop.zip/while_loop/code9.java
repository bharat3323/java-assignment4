class Nine {
	public static void main(String[] args) {
		int num = 214367689;
		int rem = 0;
		int ecnt = 0;
		int ocnt = 0;
		while(num>0){
			rem=num%10;
			num=num/10;
			if(rem%2==0){
				ecnt++;
			}else{
				ocnt++;
			}
			
		}
		System.out.println("even count :"+ecnt);
                System.out.println("odd count :"+ocnt);
	}
}
