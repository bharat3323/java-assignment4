class Two {
	public static void main(String[] args) {
		for(int i=150;i<=198;i++){
		       if(i*i%2==1){
		       System.out.println(i);
		       }
		}
	}
}	
