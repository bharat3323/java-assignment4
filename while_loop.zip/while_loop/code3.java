class Three {
	public static void main(String[] args) {
		char ch ='A';
		for(int i=1;i<=6;i++){
			System.out.println(ch++);
		}
	}
}

